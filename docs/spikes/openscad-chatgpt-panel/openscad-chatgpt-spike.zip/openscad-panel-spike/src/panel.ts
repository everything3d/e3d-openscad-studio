import {App} from '@modelcontextprotocol/ext-apps';
import {parseOFF} from '../vendor/openscad/off';
declare const ASSET_ORIGIN: string;
const origin=ASSET_ORIGIN;
const mount=crypto.randomUUID();
document.getElementById('mount')!.textContent=mount;
const records:any[]=[];
const log=(entry:any)=>{records.push({...entry,mount,time:new Date().toISOString()});document.getElementById('log')!.textContent=JSON.stringify(records,null,2);console.log('E3D_SPIKE',JSON.stringify(entry));};
addEventListener('securitypolicyviolation',(e:SecurityPolicyViolationEvent)=>log({kind:'csp',directive:e.effectiveDirective,blockedURI:e.blockedURI,policy:e.originalPolicy}));
addEventListener('error',e=>log({kind:'error',error:e.message}));
const app=new App({name:'e3d-spike',version:'0.1.0'},{});
app.connect().then(()=>log({kind:'bridge',status:'connected'})).catch(e=>log({kind:'bridge',error:String(e)}));
let worker:Worker|undefined;
let counter=0;
const pending=new Map<number,{resolve:Function,reject:Function}>();
async function startWorker(){
 const source=await (await fetch(origin+'/spike-worker.js')).text();
 const variants=[{name:'A blob',url:URL.createObjectURL(new Blob([`globalThis.__ASSET_ORIGIN__=${JSON.stringify(origin)};\n`,source],{type:'text/javascript'}))},{name:'B remote classic (cross-origin may be refused)',url:origin+'/spike-worker.js?origin='+encodeURIComponent(origin)}];
 for(const v of variants){
  try{
   const w=new Worker(v.url);
   await new Promise<void>((resolve,reject)=>{const t=setTimeout(()=>reject(new Error('Worker ready timeout (15 s)')),15000);w.onmessage=e=>{if(e.data.kind==='ready'){clearTimeout(t);resolve();}};w.onerror=e=>{clearTimeout(t);reject(new Error(e.message||'Worker script failed'));};});
   w.onmessage=e=>{const d=e.data;if(d.kind){log(d);return;}const p=pending.get(d.id);pending.delete(d.id);if(p)d.ok?p.resolve(d):p.reject(new Error(d.error+'\n'+d.log));};
   log({check:1,status:'PASS',variant:v.name});return w;
  }catch(e){log({check:1,status:'FAIL',variant:v.name,error:String(e)});}
 }
 throw new Error('Neither Worker variant worked. Main-thread probe requires a separate run.');
}
async function render(code:string,probeOnly=false,format='off'){worker??=await startWorker();const id=++counter;return new Promise<any>((resolve,reject)=>{const t=setTimeout(()=>{pending.delete(id);reject(new Error('Render timeout (120 s)'));},120000);pending.set(id,{resolve:(d:any)=>{clearTimeout(t);resolve(d);},reject:(e:any)=>{clearTimeout(t);reject(e);}});worker!.postMessage({id,code,probeOnly,format});});}
const code='cylinder(h=10, r=5, $fn=64); color("red") cube(4);';
async function run(full=false){try{
 if(full){worker?.terminate();worker=undefined;}
 const cold=await render(code,!full);
 if(!full){log({kind:'stop',reason:'Check 2 definitive; remaining checks intentionally not run'});return;}
 const mesh=parseOFF(cold.data); const warm=await render(code);log({check:4,status:'PASS',triangles:mesh.triangles.length/3,coldMs:cold.ms,warmMs:warm.ms,coloredFaces:!!mesh.faceColors,format:'OFF'});
 const stl=await render(code,false,'binstl');log({kind:'STL',bytes:stl.data.byteLength,triangles:new DataView(stl.data).getUint32(80,true)});
 const f=await fetch('https://fonts.gstatic.com/s/amaticsc/v28/TUZyzwprpvBS1izr_vO0DQ.ttf');if(!f.ok)throw new Error('Font HTTP '+f.status);log({check:5,status:'PASS',fontBytes:(await f.arrayBuffer()).byteLength});
 const text=await render('text("Hi", font="Amatic SC");',false,'svg');log({kind:'text-compile',ok:true,bytes:text.data.byteLength,log:text.log});
 await app.updateModelContext({content:[{type:'text',text:'SPIKE_TOKEN_7731 compile ok'}]});log({check:7,status:'SENT_NOT_YET_VERIFIED'});
 }catch(e){log({kind:'run-error',error:String(e)});}}
document.getElementById('probe')!.onclick=()=>run();
document.getElementById('full')!.onclick=()=>run(true);
document.getElementById('export')!.onclick=()=>{const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([JSON.stringify(records,null,2)],{type:'application/json'}));a.download='spike-evidence.json';a.click();};
log({kind:'mount',mount,origin,userAgent:navigator.userAgent});
run();
