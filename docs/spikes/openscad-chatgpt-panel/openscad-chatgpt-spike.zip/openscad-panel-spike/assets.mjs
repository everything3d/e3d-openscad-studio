import express from 'express';
const app=express();app.use((req,res,next)=>{res.set('Access-Control-Allow-Origin','*');next();});
app.use(express.static('public',{setHeaders:(res,path)=>{if(path.endsWith('.wasm'))res.set('Content-Type','application/wasm');}}));
app.listen(8080,'127.0.0.1',()=>console.log('Assets http://127.0.0.1:8080'));
