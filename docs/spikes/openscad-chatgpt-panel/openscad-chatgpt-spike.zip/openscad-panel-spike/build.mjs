import {build} from 'esbuild';
import {readFile,writeFile,mkdir} from 'node:fs/promises';
await mkdir('dist',{recursive:true});
await build({entryPoints:['vendor/mcp-extensions/src/server/index.ts'],bundle:true,platform:'node',format:'esm',packages:'external',outfile:'vendor/mcp-extensions/dist/server/index.js'});
await build({entryPoints:['src/worker.ts'],bundle:true,format:'iife',platform:'browser',outfile:'public/spike-worker.js'});
await build({entryPoints:['src/panel.ts'],bundle:true,format:'iife',platform:'browser',outfile:'dist/panel.js'});
const js=await readFile('dist/panel.js','utf8');
await writeFile('dist/spike.html',`<!doctype html><meta charset="utf-8"><title>OpenSCAD wasm spike</title><style>body{font:14px system-ui;padding:16px}pre{white-space:pre-wrap;overflow-wrap:anywhere}button{padding:8px;margin:4px}</style><h2>OpenSCAD wasm spike</h2><p>Stops after Check 2. Mount ID: <span id="mount"></span></p><button id="probe">Run key checks</button><button id="full">Run remaining compile/font/context checks</button><button id="export">Download evidence</button><pre id="log"></pre><script>${js.replaceAll('</script','<\\/script')}</script>`);
