from pathlib import Path
p=Path('vendor/openscad/render.worker.ts')
s=p.read_text()
s=s.replace("const wasmUrl = '/openscad/openscad.wasm'", "const origin = new URL(self.location.href).searchParams.get('origin') || '';\nconst wasmUrl = origin + '/openscad.wasm'")
s=s.replace("const fontsZipUrl = '/openscad/fonts.zip'", "const fontsZipUrl = origin + '/fonts.zip'")
s=s.replace("`${self.location.origin}/api/fonts/catalog`", "`${origin}/font-catalog.json`")
s=s.replace("`${self.location.origin}/api/fonts?${params}`", "'https://fonts.gstatic.com/s/amaticsc/v28/TUZyzwprpvBS1izr_vO0DQ.ttf'")
s=s.replace("    wasmBytes = wasm", "    self.postMessage({kind:'check',check:3,status:'PASS',bytes:wasm.byteLength});\n    wasmBytes = wasm")
s=s.replace("    wasmBinary: wasmBytes,", """    wasmBinary: wasmBytes,
    instantiateWasm: (imports: WebAssembly.Imports, success: Function) => {
      const t = performance.now();
      WebAssembly.instantiateStreaming(new Response(wasmBytes, {headers:{'Content-Type':'application/wasm'}}), imports).then(result => {
        self.postMessage({kind:'check',check:2,status:'PASS',ms:performance.now()-t,method:'WebAssembly.instantiateStreaming',exports:Object.keys(result.instance.exports).length});
        success(result.instance, result.module);
      }).catch(err => {
        self.postMessage({kind:'check',check:2,status:'FAIL',error:String(err),stack:err.stack});
      });
      return {};
    },""")
s=s.replace("  const fs = instance.FS", "  if ((self as any).__probeOnly) return {data:new ArrayBuffer(0),log:'Stopped after definitive Check 2'};\n  const fs = instance.FS")
s=s.replace("  const { id, code, files, format = 'off' } = e.data", "  const { id, code, files, format = 'off' } = e.data\n  ;(self as any).__probeOnly = (e.data as any).probeOnly\n  const started = performance.now()")
s=s.replace("const msg: RenderOk = { id, ok: true, data, format, log }", "const msg = { id, ok: true, data, format, log, ms:performance.now()-started }")
s += "\nself.postMessage({kind:'ready'});\n"
p.write_text(s)
