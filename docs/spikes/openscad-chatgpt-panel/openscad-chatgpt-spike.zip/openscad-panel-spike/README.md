# OpenSCAD ChatGPT panel spike

Minimal adaptation of the Bits & Bolts `cad.tray` tool/resource registration and E3D Studio's existing renderer. Default run stops immediately after definitive wasm instantiation (Check 2), as requested.

## Reproduce

Requires Node 22+ and cloudflared.

```sh
npm ci
npm run build
node assets.mjs
cloudflared tunnel --url http://127.0.0.1:8080 --no-autoupdate
# Copy the first tunnel's HTTPS origin:
ASSET_ORIGIN=https://YOUR-ASSET-TUNNEL.trycloudflare.com npm start
cloudflared tunnel --url http://127.0.0.1:8799 --no-autoupdate
```

Connect the second tunnel's `/mcp` URL as a custom MCP server in ChatGPT, no authentication. Install the personal plugin and invoke `render_scad_test` in a new conversation. Inspect on-screen JSON and `E3D_SPIKE` console entries. Do not interpret local browser results as ChatGPT CSP evidence.

The optional remaining-checks button compiles colored OFF twice in a fresh Worker using the original parser, separately exports binary STL, checks a direct Amatic SC TTF request, compiles text, and sends model context. Check 6 is manual: note mount UUID, invoke UI-less `ping` in chat, compare mount UUID. Check 7 is manual: ask ChatGPT what token the panel sent, without supplying the expected token in that prompt.

## Provenance and adaptations

- OpenAI mcp-extensions commit `ca16cb3bc015baaa1b849082d8755bbef18770cb`; Bits & Bolts thread metadata/registration pattern, reduced to two tools and HTTP transport. SDK source vendored and installed as a local dependency.
- E3D Studio commit `ae22dac09b934f2375ea4e0482a39e5b4164fdb1`; copied vendor loader, compile worker, font helpers, OFF parser, wasm and font ZIP.
- Worker edits: absolute asset URLs, direct Amatic SC TTF URL instead of studio proxy, streaming instantiate hook with the existing Emscripten imports, structured evidence, and probe-only early return. `adapt.py` records these edits; do not rerun it over already adapted files.
- Studio currently caches wasm bytes and creates a fresh Emscripten instance per render; warm timing means cached assets plus a new instance, not a reused runtime.
- Binary is 9,603,115 bytes (see report for exact measured size), rather than the brief's approximate 16 MB. No arbitrary 16 MB host cap can be inferred from a smaller successful transfer.
- Variant B is a direct classic Worker URL on the asset origin. Because the iframe has a different origin, browser same-origin restrictions can reject it independently of CSP. It must not be reported as a same-origin worker.
- OFF is the colored preview path. The optional run also performs a separate `binstl` compile. Check 4 timings measure OFF; STL cannot preserve face colors. The 2D text test uses SVG output because OFF requires a 3D model.

CSP metadata uses exactly the asset origin for resources/connect and fonts.gstatic.com for connect. It does not add unsafe-eval or wasm-unsafe-eval.
